<?php

namespace App\Admin\Resources\NotificationTemplateResource\Pages;

use App\Admin\Resources\NotificationTemplateResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNotificationTemplate extends CreateRecord
{
    protected static string $resource = NotificationTemplateResource::class;
}
