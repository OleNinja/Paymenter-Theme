<?php

namespace App\Models;

use OwenIt\Auditing\Models\Audit as AuditModel;

class Audit extends AuditModel
{
    //
}
