<?php

namespace App\Models\Traits;

trait Settingable
{
    //
}
